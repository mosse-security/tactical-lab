#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "pupy_load.h"

int main(int argc, char *argv[]){
	return mainThread(NULL);
}

