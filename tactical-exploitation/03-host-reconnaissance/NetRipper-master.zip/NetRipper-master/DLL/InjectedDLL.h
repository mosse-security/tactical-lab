
#ifndef _INJECTEDDLL_H_
#define _INJECTEDDLL_H_

#include <string>
#include <vector>
#include <windows.h>
#include <TlHelp32.h> 
#include <stdio.h>

using namespace std;

// Function prototypes

void Inject();
void Unhook();

#endif
