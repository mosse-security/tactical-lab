networkenum
===========

Using Scapy framework for enumerating a network. networkenum.py is the main script that calls other scripts "icmp_ping.py", "arp_ping.py" and syn_scan.py. As more features will be added, networkenum.py will be updated to call them. You can read more about the project at my blog http://blog.l3g3ndary.org.

Shout Outs:

Special thanks to Dan Melfi for helping me whenever I got stuck.
