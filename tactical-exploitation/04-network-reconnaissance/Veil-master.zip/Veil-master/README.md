#Veil

Veil is the superproject for the stable-state releases of the tools in the [Veil-Framework](https://www.veil-framework.com/).


To update all projects and settings appropriately, run ./update.sh


The Veil-Framework is a red team toolkit focused on evading detection. It currently contains [Veil-Evasion](https://github.com/Veil-Framework/Veil-Evasion) for generating AV-evading payloads, [Veil-Catapult](https://github.com/Veil-Framework/Veil-Catapult) for delivering them to targets, and [Veil-PowerView](https://github.com/Veil-Framework/Veil-PowerView) for gaining situational awareness on Windows domains.


The Veil-Framework is currently under active support by [@HarmJ0y](https://twitter.com/harmj0y), [@ChrisTruncer](https://twitter.com/ChrisTruncer), and [@TheMightyShiv](https://twitter.com/TheMightyShiv).
