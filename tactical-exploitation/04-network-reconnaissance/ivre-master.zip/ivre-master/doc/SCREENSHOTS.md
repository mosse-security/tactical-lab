# IVRE's screenshots gallery #

![screenshot](screenshots/webui-home-heatmap.png)

Home page with "heatmap" IP addresses.


![screenshot](screenshots/webui-details-heatmapzoom.png)

Scan result details, using the "heatmap" IP addresses to "zoom" in the
address space


![screenshot](screenshots/webui-screenshots-solar-world.png)

Screenshots containing the word "solar" and map


![screenshot](screenshots/webui-topproducts-80.png)

Most common products seen on port 80


![screenshot](screenshots/webui-tooltip-topenipvendors.png)

Help tooltip and most common ENIP vendors


---

This file is part of IVRE. Copyright 2011 - 2015
[Pierre LALET](mailto:pierre.lalet@cea.fr)
