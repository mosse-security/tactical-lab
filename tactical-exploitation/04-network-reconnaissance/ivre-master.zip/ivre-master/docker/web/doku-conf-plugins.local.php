<?php
$plugins['authad']    = 0;
$plugins['authldap']  = 0;
$plugins['authmysql'] = 0;
$plugins['authpgsql'] = 0;
