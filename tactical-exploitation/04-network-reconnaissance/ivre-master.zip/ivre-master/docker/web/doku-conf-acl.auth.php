# acl.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Access Control Lists
#
*               @ALL          8
