<?php
$conf['title'] = 'IVRE';
$conf['lang'] = 'en';
$conf['license'] = '0';
$conf['useacl'] = 0;
$conf['superuser'] = '@admin';
$conf['disableactions'] = 'register';
$conf['start'] = 'doc:readme';
$conf['userewrite'] = 1;
