-- ex: set ff=dos
-- $Id$

-- map BROWSE.OS hints

INSERT INTO map(maptype,map,src,val)VALUES('OS', 'WinNT4',  'BROWSE.OS','4.0');
INSERT INTO map(maptype,map,src,val)VALUES('App','Samba',   'BROWSE.OS','4.9');
INSERT INTO map(maptype,map,src,val)VALUES('OS', 'WinNT5',  'BROWSE.OS','5.0');
INSERT INTO map(maptype,map,src,val)VALUES('OS', 'WinNT5.1','BROWSE.OS','5.1');
INSERT INTO map(maptype,map,src,val)VALUES('OS', 'WinNT5.2','BROWSE.OS','5.2');
INSERT INTO map(maptype,map,src,val)VALUES('OS', 'WinNT6',  'BROWSE.OS','6.0');

