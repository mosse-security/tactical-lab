-- ex: set ff=dos
-- $Id$

-- map IPv4.* hints

INSERT INTO map(maptype,map,src,val)VALUES('Role','Router', 'IPv4.Router','');

