-- ex: set ff=dos
-- $Id$

-- map CDP.* hints

INSERT INTO map(maptype,map,src,val)VALUES('Dev','Cisco-Catalyst-1900', 'CDP.Platform','cisco 1900');

