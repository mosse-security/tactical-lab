<?php
$DB_PATH="../db/db";
?>
