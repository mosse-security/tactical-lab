version = "2.0"
message = "\n... SEES ... "
disclamer = "Using SEES for malicious purposes is illegal. USE AT YOUR OWN RISK, Agree (Y|n)"
wrong_option = "Wrong option, Please use \"Y|N\""
