<?php

/*
|--------------------------------------------------------------------------
| SeeS Config
|--------------------------------------------------------------------------
|
*/
//$config['sees_root_dir'] =  'C:/sees/';
$config['sees_root_dir'] =  '/usr/local/sees/';
$config['sees_config_path'] =  $config['sees_root_dir'] . '/config/sees.cfg';
$config['sees_mail_path'] =  $config['sees_root_dir'] . '/config/mail.user';
$config['sees_data_dir'] =  $config['sees_root_dir'] . '/data/';

