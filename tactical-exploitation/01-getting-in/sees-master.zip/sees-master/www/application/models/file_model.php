<?php

    class File_Model extends CI_Model {

        var $name = '';
        var $size = '';
        var $date = '';
        
        function __construct()
        {          
            parent::__construct();
        }
    
    }