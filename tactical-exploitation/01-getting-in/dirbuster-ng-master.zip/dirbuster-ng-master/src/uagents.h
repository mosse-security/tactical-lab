#ifndef UA_H
  #define UA_H
  const char* resolve_ua(char*);
#endif
