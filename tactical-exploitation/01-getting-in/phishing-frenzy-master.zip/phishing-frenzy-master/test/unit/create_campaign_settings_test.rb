require 'test_helper'

class CreateCampaignSettingsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
