require 'test_helper'

class BlastTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
