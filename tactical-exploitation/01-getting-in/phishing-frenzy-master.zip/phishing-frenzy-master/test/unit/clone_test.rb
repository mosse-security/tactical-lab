require 'test_helper'

class CloneTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
