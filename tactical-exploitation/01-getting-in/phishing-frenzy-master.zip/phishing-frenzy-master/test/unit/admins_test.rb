require 'test_helper'

class AdminsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
