require 'test_helper'

class CreateTemplatesTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
