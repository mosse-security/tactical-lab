require 'test_helper'

class CampaignsHelperTest < ActionView::TestCase
end
