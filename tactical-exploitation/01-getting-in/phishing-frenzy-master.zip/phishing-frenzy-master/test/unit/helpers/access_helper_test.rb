require 'test_helper'

class AccessHelperTest < ActionView::TestCase
end
