require 'test_helper'

class VictimsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
