require 'test_helper'

class EmailSettingsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
