require 'test_helper'

class PhishingFrenzyMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
