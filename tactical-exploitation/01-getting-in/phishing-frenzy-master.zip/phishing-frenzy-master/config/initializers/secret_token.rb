# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PhishingFramework::Application.config.secret_token = '27de6ab54781e07ecbe9b3e814c6698813d070f310e5ed5f01ba14eb1f2114cd8a0a5eccff82738654f5980516427bf87c4d9b57229ac9b8ee515952a302418b'
