class Statistics < ActiveRecord::Base
	belongs_to :campaign
end
