class Clone < ActiveRecord::Base
  attr_accessible :name, :page, :url
end
