class AccessController < ApplicationController

	def index
		menu
		render('menu')
	end

	def menu
		# display text & links
	end

end
