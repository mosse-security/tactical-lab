class SystemLogsController < ApplicationController
end
