class ReportDecorator < Draper::Decorator
  include IconDecorator
end
