FactoryGirl.define do
  factory :attachment, class: "attachment" do
    file "efax.jpg"
    function "website"
  end

end
