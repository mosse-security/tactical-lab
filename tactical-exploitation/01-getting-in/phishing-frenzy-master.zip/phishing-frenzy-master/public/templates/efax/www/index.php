<?php 

  $uid = $_GET['uid'];
  $ip = $_SERVER["REMOTE_ADDR"];
  $browser = $_SERVER['HTTP_USER_AGENT'];
  $host = $_SERVER['HTTP_HOST'];

  $url = "http://" . explode(".",$host,2)[1] . '/reports/results/'; 
  $data = array('uid' => $uid, 'browser_info' => $browser, 'ip_address' => $ip);

  // use key 'http' even if you send the request to https://...
  $options = array(
          'http' => array(
          'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
          'method'  => 'POST',
          'content' => http_build_query($data),
          ),
  );
  $context  = stream_context_create($options);
  $result = file_get_contents($url, false, $context);

  //echo(null);
  var_dump($result);
?>






   



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>eFax Worldwide</title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    
    <script charset="UTF-8" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/common/javascript/mbox.js?av=RHOf" type="text/javascript">//</script>
    <script charset="UTF-8" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/common/javascript/mootools1-2_corenmore.js?av=Mcf6" type="text/javascript">//</script>
    <script charset="UTF-8" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/common/javascript/commonJ2Scripts.js?av=OdVg" type="text/javascript">//</script>
    <link type="image/ico" href="http://en.efax.com/efaxieu-cms-public/docroot/efaxieu/resources/images/newImages/favicon.ico" rel="shortcut icon"/>
    <link type="text/css" href="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/css/globalGateway.css?av=MpT-" rel="stylesheet"/>
    
    
    

    
    
        
        





<style type="text/css">
<!--
.efaxRoundedBox_body{border-right:1px solid #D6D6D6; border-left:1px solid #D6D6D6;}
.efaxRoundedBox_tile_footer {background:transparent url(http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/globalGateway/gblGate_roundedFooter_bottom.gif?av=fPQg) no-repeat bottom; padding-bottom:10px}
.efaxRoundedBox_left_footer{background-image:none;}
.efaxRoundedBox_right_footer{background-image:none;}

#footerLinks li,
#footerLinks li a,
#footerLinks li a:link,
#footerLinks li a:visited {color:#BBBBBB;text-decoration:none;}
#footerLinks li a:hover,
#footerLinks li a:active { color:#0066CC; text-decoration:none;}
-->
</style>
      
      
    
</head>


<body  style="line-height:130%; color:#424242; background-image:none; background-color: #FFF">





<div style="display:none;" class="debugBox" id="debug">
  <!-- Debug Info
  id = "TPA2X0"
  skin = ""
  title = "eFax Worldwide"
  handle = "/efaxi/content/globalGateway"
  cache key = "/efaxi/content/globalGateway.efbfbd1a24efbfbd28efbfbdefbfbd70efbfbd16efbfbd4528c882
	(CurrentPage=globalGateway, OFFERCODE=null, SSL-Detected=, akamaiCountry=US, brand=efaxi)"
  nodename = "globalGateway" 
  template = "efaxDomesticTemplate"
  timestamp = "2013-02-19 17:29:26.153"
  -->
</div>





<table id="mainContent" align="center" cellpadding="0" cellspacing="0" border="0">

  
  <tr>
    <td>
        <div id="header">
      
        
        








  
    












  
  
    <div id="headerLogo"><a href="http://www.efax.com/"><img border="0" src="http://home.efax.com/CBD/5/default/default--web-logo.gif" alt="efaxi" /></a>
</div>
  



    
  
      
      
    </td>
  </tr>
    <tr>
    <td>
      
        
        





<div style="margin-top:10px; margin-bottom:0px">
<table cellspacing="0" cellpadding="0" border="0" >
<tbody>
<tr>
<td><div class="mboxDefault"><a href="http://www.efax.com/efax-signup/fax-numbers" id="lnk_header_signup">
<img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/domTopNav/navGetStarted2_off.gif?av=P9RL" onmouseover="toggleImage(this)" onmouseout="toggleImage(this)" alt="Sign Up" id="signup" class="topNav" BORDER="0" /></a></div>
<script charset="UTF-8" language="Javascript1.2" type="text/javascript">mboxCreate('EFAX_topnavsignup_switch');</script></td>
<td><a id="lnk_header_products" href="http://www.efax.com/products/internet-fax"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/domTopNav/navProducts2_off.gif?av=GdYZ" onmouseover="toggleImage(this)" onmouseout="toggleImage(this)" alt="Products" class="topNav" BORDER="0" /></a></td>
<td><a href="http://www.efax.com/pricing"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/domTopNav/navPricing2_off.gif?av=UZZY" onmouseover="toggleImage(this)" onmouseout="toggleImage(this)" alt="Pricing" id="lnk_header_pricing" class="topNav" BORDER="0" /></a></td>
<td><a href="http://www.efax.com/promotions"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/domTopNav/navPromotions2_off.gif?av=cmQr" onmouseover="toggleImage(this)" onmouseout="toggleImage(this)" alt="Promotions" id="lnk_header_promotions" class="topNav" BORDER="0" /></a></td>
<td><a href="http://www.efax.com/products/corporate-fax-solutions"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/domTopNav/navEnterprise2_off.gif?av=NXL2" onmouseover="toggleImage(this)" onmouseout="toggleImage(this)" alt="Enterprise" id="lnk_header_enterprise" class="topNav" BORDER="0" /></a></td>
<td><a href="http://www.efax.com/contact"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/domTopNav/navContact2_off.gif?av=9b3H" onmouseover="toggleImage(this)" onmouseout="toggleImage(this)" alt="Contact Us" id="lnk_header_contact" class="topNav" BORDER="0" /></a></td>
<td><a href="https://www.efax.com/login"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/domTopNav/navMyAccount2_off.gif?av=m8XE" onmouseover="toggleImage(this)" onmouseout="toggleImage(this)" alt="My Account" id="lnk_header_login" class="topNav" BORDER="0" /></a></td>
</tr>
</tbody>
</table>
</div>
      
      
        </div>
    </td>
  </tr>
  <tr>
    <td>
      
        
        






  
  

  <div id="textImageTable" style="width:100%;clear:both">
    <div class="mboxDefault" style="visibility: visible; display: block; width:800px;" >
      
        <table align="center" cellpadding="0" cellspacing="0" border="0"
               style="width:100%; padding-top:0px; margin-top:0px;">
            
            
                
                
                    <tr>
                        
                            <td valign="top">
                                    
                                            








<div class="textImageContent" style="margin-top:10px !important; margin-top:5px;margin-bottom:6px;margin-left:0;margin-right:0;text-align:left;width:612px;">
  
  
    
    
      <img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/globalGateway/defaultPano.jpg?av=9ZRH" alt="eFax saves me time, money and paper" id="pano_gblGwy"/>
    
  
  
  
  
</div>

                            </td>
                        
                            <td valign="top">
                                    
                                            









<table cellspacing="0" cellpadding="0" border="0" style="margin-top:10px !important; margin-top:5px; margin-bottom:6px; padding: 0; width: 188px; height:153px;">
<tbody>
<tr valign="top">
<td style="height: 2px; background-color: rgb(255, 255, 255); background-image: url(http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/questions_tileTop.gif); background-repeat: repeat-x;"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/pixel.gif" alt="space" width="1"/></td>
<td style="width: 4px; text-align: left; background-color: rgb(255, 255, 255);"><img style="display: block;" alt="space" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/questions_TR.gif" align="right" border="0" hspace="0" vspace="0" width="4"></td>
</tr>
<tr>
    <td style="width:188px; background-image: url(http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/backgroundGradient.gif); background-repeat: repeat-x; background-position: bottom left">
        <table cellpadding="0" cellspacing="0" border="0" style="margin:0 10px">
            <tr>
                <td style="font-weight:bold;color:#0066CC;font-size:12px;padding-bottom:3px;">Sales Questions?</td>
                </tr>
    <tr>
                <td>
                    
                        <select onchange="updateNumber();" id="ipCountry" name="ipCountry" class="select"
                                style="width: 158px;">
                            <option value="AR" phoneTollFree="0800-333-0775" phoneDirect="infoar@mail.efax.com">Argentina</option>
<option value="AU" phoneTollFree="1-800-132-818" phoneDirect="helpau@mail.efax.com">Australia</option>
<option value="AT" phoneTollFree="0800 296 152" phoneDirect="+43 1 79576212">Austria</option>
<option value="BE" phoneTollFree="0800 80 872" phoneDirect="+32 2 200 62 35">Belgium</option>
<option value="BR" phoneTollFree="customerservice@mail.efax.com" phoneDirect="infobr@mail.efax.com">Brazil</option>
<option value="BG" phoneTollFree="02 437 26 34" phoneDirect="+359 (0)2 437 26 34">Bulgaria</option>
<option value="CA" phoneTollFree="1 (800) 287-3499" phoneDirect="1 (323) 817-3205">Canada</option>
<option value="CL" phoneTollFree="(56 2) 581 4454" phoneDirect="infocl@mail.efax.com">Chile</option>
<option value="HR" phoneTollFree="+44 20 3147 4872 (UK)" phoneDirect="">Croatia</option>
<option value="CY" phoneTollFree="+44 870 711 3311" phoneDirect="+44 20 3147 4872 (UK)">Cyprus</option>
<option value="CZ" phoneTollFree="255 709 439" phoneDirect="+420 255 709 439">Czech Republic</option>
<option value="DK" phoneTollFree="08 233 28 05" phoneDirect="">Denmark</option>
<option value="EG" phoneTollFree="customerservice@mail.efax.com" phoneDirect="">Egypt</option>
<option value="EE" phoneTollFree="+44 20 3147 4872 (UK)" phoneDirect="">Estonia</option>
<option value="FI" phoneTollFree="09 7479 0010" phoneDirect="+358 (0)9 7479 0010">Finland</option>
<option value="FR" phoneTollFree="01 70 70 96 64" phoneDirect="+33 (0)1 70 70 96 64">France</option>
<option value="DE" phoneTollFree="0800 0003164" phoneDirect="030 56837002">Germany</option>
<option value="GR" phoneTollFree="0210 969 6422" phoneDirect="">Greece</option>
<option value="HK" phoneTollFree="852 2815 5552" phoneDirect="hk@mail.efax.com">Hong Kong</option>
<option value="HU" phoneTollFree="01 235 53 11" phoneDirect="">Hungary</option>
<option value="IN" phoneTollFree="000-800-100-4104" phoneDirect="info@efax.co.in">India</option>
<option value="IE" phoneTollFree="1800 882 231" phoneDirect="+353 1 656 4909">Ireland</option>
<option value="IL" phoneTollFree="customerservice@mail.efax.com" phoneDirect="">Israel</option>
<option value="IT" phoneTollFree="800 979 198" phoneDirect="+39 026 9430336">Italy</option>
<option value="JP" phoneTollFree="03-4520-9261" phoneDirect="sales@efax.co.jp">Japan</option>
<option value="LV" phoneTollFree="+44 20 3147 4872 (UK)" phoneDirect="">Latvia</option>
<option value="LT" phoneTollFree="+44 20 3147 4872 (UK)" phoneDirect="">Lithuania</option>
<option value="LU" phoneTollFree="27 30 20 11" phoneDirect="">Luxembourg</option>
<option value="MY" phoneTollFree="customerservice@mail.efax.com" phoneDirect="+1 323 817 3207">Malaysia</option>
<option value="MX" phoneTollFree="(55) 4631 1211" phoneDirect="infomx@mail.efax.com">Mexico</option>
<option value="NL" phoneTollFree="0800 0200377" phoneDirect="+31 20 714 3585">Netherlands</option>
<option value="NZ" phoneTollFree="09 909 6000" phoneDirect="infonz@mail.efax.com">New Zealand</option>
<option value="NO" phoneTollFree="23 50 03 90" phoneDirect="">Norway</option>
<option value="PE" phoneTollFree="(511) 700 9301" phoneDirect="infope@mail.efax.com">Peru</option>
<option value="PH" phoneTollFree="customerservice@mail.efax.com" phoneDirect="">Philippines</option>
<option value="PL" phoneTollFree="12 395 08 20" phoneDirect="+48 12 395 08 20">Poland</option>
<option value="PT" phoneTollFree="021 424 51 40" phoneDirect="+44 20 3147 4872 (UK)">Portugal</option>
<option value="KR" phoneTollFree="customerservice@mail.efax.com" phoneDirect="info@efax.co.kr">Republic of Korea (South)</option>
<option value="RO" phoneTollFree="021 204 70 05" phoneDirect="">Romania</option>
<option value="SG" phoneTollFree="+65 6347 5065" phoneDirect="customerservice@mail.efax.com">Singapore</option>
<option value="SK" phoneTollFree="02 6862 2600" phoneDirect="+421 (0)2 6862 2600">Slovakia</option>
<option value="SI" phoneTollFree="01 828 0241" phoneDirect="+386 (0)1 828 0241">Slovenia</option>
<option value="ES" phoneTollFree="900 811 915" phoneDirect="">Spain</option>
<option value="SE" phoneTollFree="08 403 049 61" phoneDirect="+46 (0)8 403 049 61">Sweden</option>
<option value="CH" phoneTollFree="044 595 94 09" phoneDirect="+41 (0)44 595 94 09">Switzerland</option>
<option value="TW" phoneTollFree="00801-14-7044" phoneDirect="infotw@mail.efax.com">Taiwan</option>
<option value="UK" phoneTollFree="020 3147 4872" phoneDirect="+44 20 3147 4872">United Kingdom</option>
<option selected="selected" value="US" phoneTollFree="1 (800) 958-2983" phoneDirect="1 (323) 817-3207">United States</option>

                        </select>
                    
                </td>
                </tr>
    <tr>
                <td>
                    <div style="border-top: 1px solid #CCC;margin:4px 0"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/pixel.gif" alt="space" width="1" height="1"/></div>
                    <table cellpadding="0" cellspacing="0" border="0" style="margin-bottom:3px; color:#333; font-weight:bold;;">
                        <tr>
                            <td rowspan="2" style="width:23px;text-align:center"><img align="middle"
                                                                    src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/phoneIcon.jpg"
                                                                    alt="phone icon"/></td>
                            <td style="font-size:12px;"><span id="phoneBoxTollFree">1 (800) 958-2983</span></td>
                            </tr>
                            
                            
                            
                              <tr>
                                <td style="font-size:12px;">
                                    <span id="phoneBoxDirect">1 (323) 817-3207</span>
                                </td>
                              </tr>
                            
                    </table>
                </td>
            </tr>
<tr>
    <td style="text-align: right; padding-bottom:5px;padding-right:5px">
        <a style="font-weight:bold; color:#666; font-size: 12px; text-decoration: none;" href="javascript:launchEstara()">Want Us to Call You?</a>&nbsp;<img
            src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/arrow.gif" alt="red arrow"/>
    </td>
    </tr>
    <tr>
    <td style="border-top: 1px solid #CCC;">
        <table cellpadding="0" cellspacing="0" border="0" style="margin-top:5px;">
            <tr>
                <td style="width:23px"><img id="liveChatDiv" align="middle"
                                            src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/liveChat.gif"
                                            alt="chat icon"/></td>
                <td><a style="text-align:left; font-weight:bold;color:#666;font-size:12px; text-decoration:none;"
                       href="javascript:MM_openBrWindow('http://server.iad.liveperson.net/hc/62672927/?SESSIONVAR!skill=Sales&SESSIONVAR!origin=efaxsales&cmd=file&file=visitorWantsToChat&site=62672927&byhref=1','childWin','scrollbars=no,toolbar=no,resize=yes,height=350,width=480')">Live
                    Sales Chat</a>&nbsp;<img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/arrow.gif"
                                             alt="red arrow"/></td>
            </tr>
        </table>
    </td>
</tr>
</table>
    </td>
    <td style="width:4px; background-color: rgb(255, 255, 255); background-image: url(http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/questions_tileRight.gif); background-repeat: repeat-y;"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/pixel.gif" alt="space" width="1"/></td>
  </tr>
<tr valign="top">
<td style="height: 11px; background-color: rgb(255, 255, 255); background-image: url(http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/questions_tileBottom.gif); background-repeat: repeat-x;"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/pixel.gif" alt="space" width="1"/></td>
<td style="width: 4px; text-align: left; background-color: rgb(255, 255, 255);"><img style="display: block;" alt="space" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesPanorama/questions_BR.gif" align="right" border="0" hspace="0" vspace="0" width="4"></td>
</tr>
</tbody>
</table>

<script language="javascript" type="text/javascript">
  function launchEstara(){
    if(getCookie('VID') == null || getCookie('VID') == ''){setCookieFromQSVariable('VID');}
    if(getCookie('CMP') == null || getCookie('CMP') == ''){setCookieFromQSVariable('CMP');}
    var pageName = 'globalGateway';
    webVoicePop('Template=233263','var1=' + getCookie('VID'), 'var2=efaxC2CTextLink', 'var3='+ pageName, 'var4=' + getCookie('CMP'));
    }

  
  if ($('ipCountry')) {
    if ($('ipCountry').value != '') {
      $('phoneBoxTollFree').innerHTML = $('ipCountry')[$('ipCountry').selectedIndex].getAttribute('phoneTollFree');
      if ($('phoneBoxDirect')) {
        $('phoneBoxDirect').innerHTML = $('ipCountry')[$('ipCountry').selectedIndex].getAttribute('phoneDirect');
      }
    }
  
    if ($('ipCountry').length == 0 || $('ipCountry')[0].getAttribute('isCampaign')) {
      $('ipCountry').setStyle('display','none');
    }
  }

  function updateNumber() {
      if ($('ipCountry') && $('ipCountry').value != '') {
        if ($('ipCountry')[$('ipCountry').selectedIndex].getAttribute('phoneTollFree') == null) {
          document.getElementById('phoneBoxTollFree').innerHTML = '';
        } else {
          document.getElementById('phoneBoxTollFree').innerHTML = $('ipCountry')[$('ipCountry').selectedIndex].getAttribute('phoneTollFree');
        }
        if ($('phoneBoxDirect')) {
          if ($('ipCountry')[$('ipCountry').selectedIndex].getAttribute('phoneDirect') == null) {
            document.getElementById('phoneBoxDirect').innerHTML = '';
          } else {
            document.getElementById('phoneBoxDirect').innerHTML = $('ipCountry')[$('ipCountry').selectedIndex].getAttribute('phoneDirect');
          }
        }
      }
  }
</script>

<script src="https://as00.estara.com/as/InitiateCall2.php?accountid=200106288503" type="text/javascript">//</script>
                            </td>
                        
                    </tr>
                
            
            
        </table>
    </div>
    
  </div>

      
      
    </td>
  </tr>
  
<tr>
  <td>
    <table cellspacing="0" bgcolor="#FAFAFA" style="margin:5px 0px;" cellpadding="0" border="0" id="shadowMainContainer">
<tr>
          <td style="width: 7px; height:6px; text-align: left; vertical-align:top;"><img width="7" height="6" vspace="0" hspace="0" border="0" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/shadowBox/shadowBox_TL.gif" alt="space" style="display: block;"/></td>
          <td style="width: 605px; border-top: 1px solid #D9D9D9; vertical-align:top;"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/pixel.gif" alt="space" height="1" width="605"/></td>
    <td rowspan="3" style="border-right: 1px solid #D9D9D9; border-left: 1px solid #D9D9D9; background-color: #FFFEFE; vertical-align:top; width:188px">
        
            
            







<div class="mboxDefault" style="visibility: visible; display: block;" >
      
<div id="sidebarHeader" style="margin-top:;">How Does eFax Work?</div>
<div id="sidebar">
  <div style="padding:10px">
    
      <div style="clear:both;">
        
      </div>
      





<table cellspacing="0" cellpadding="0" border="0">
 <tbody>
 <tr>
 <td valign="top" rowspan="2"><img border="0" alt="" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/images/imagesSideBar/demoIcon.gif" /></td>
 <td valign="top" style="padding: 0pt 0pt 5px 5px; font-weight: bold; font-size: 12px; color: rgb(102, 102, 102); line-height: 130%;">View our demo to see eFax in Action!</td>
 </tr>
 <tr>
 <td valign="top"><a href="javascript:MM_openBrWindow('http://go.efax.com/s/r/jla/4623/demo.html','demo','scrollbars=no,toolbar=no,resize=yes,height=465,width=615')"><img border="0" alt="" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/efaxi/resources/en/localizedImages/imagesSignup/viewDemoButton.jpg" /></a></td>
 </tr>
 </tbody>
</table>
    
    
  </div>
  <div id="bottomCurve">
    <div style="width: 7px; text-align: left; float:left"><img width="7" vspace="0" hspace="0" border="0" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/shadowBox/shadowBox_BL.gif" alt="space" style="display: block;"/></div>
    <div style="width: 174px; float:left; height: 12px; background-image: url( http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/shadowBox/shadowBox_tileBottom.gif ); background-repeat: repeat-x;"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/pixel.gif" alt="space" width="1"/></div>
    <div style="width: 7px; text-align: left; float:left;"><img width="7" vspace="0" hspace="0" border="0" align="right" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/shadowBox/shadowBox_BR.gif" alt="space" style="display: block;"/></div>
  </div>
</div>
</div>
    
        
        
    </td>
</tr>
<tr>
    <td colspan="2" style="padding:20px 0px 20px 20px; border-left: 1px solid #D9D9D9; vertical-align:top;">
      
        
        







<div style="clear: both; width: 580px;"> 
<div style="padding-right: 25px; float: left; width: 355px;"> <h3 style="margin-top: 3px; color: rgb(102, 102, 102);">eFax Download</h3> 
<p>Download your eFax here:</p>

&#9674; <a href="eFax_di23-208571567114-2013234-pdf.pdf">Download - eFax_di23-208571567114-2013234.pdf</a>

</div> <div style="float: left; padding-bottom: 20px; width: 200px;"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/dms/efaxi/resources/images/world-map.gif?av=BCFZ" alt="World map" /></div> </div>

      
        
        















    







<div id="efaxRoundedBoxContainer_selectLanguage_mbox" class="mboxDefault" style="visibility: visible; display: block; float:;">
    
    <div class="efaxRoundedBoxContainer" id="efaxRoundedBoxContainer_selectLanguage" style="float:; width:570px; margin-top:20px; margin-bottom:20px; margin-left:0; margin-right:0; display:block">
        
        </div>
    </div>
    
</div>

      
      
    </td>
</tr>
<tr>
      <td colspan="3">
  <table cellspacing="0" cellpadding="0" border="0" align="center" style="margin: 0px; padding: 0px; width: 100%;">
        <tr>
  <td style="width: 7px; text-align: left; vertical-align:top;"><img width="7" vspace="0" hspace="0" border="0" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/shadowBox/shadowBox_BL.gif" alt="corner" style="display: block;"/></td>
  <td style="height: 12px; vertical-align:top; background-image: url('http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/shadowBox/shadowBox_tileBottom.gif'); background-repeat: repeat-x;"><img src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/pixel.gif" alt="space" width="1"/></td>
  <td style="width: 7px; vertical-align:top; text-align: left;"><img width="7" vspace="0" hspace="0" border="0" src="http://assetsi.efax.com.edgesuite.net/wwwi.efax.com/efaxieu-cms-public/docroot/j2core/resources/images/shadowBox/shadowBox_BR.gif" alt="corner" style="display: block;"/></td>
          </tr>
    </table>
  </td>
</tr>
    </table>
  </td>
</tr>
        
  

  
  <tr>
    <td>
        
            
            







<div id="footer" style="width: 800px; color: rgb(187, 187, 187);"> <div style="float: right;" id="j2globalLogo"><a href="http://www.j2global.com" target="_blank" id="lnk_footer_j2global"><span>j2 Global</span></a></div> <div> <div> <div id="footerLinks" style="color: rgb(187, 187, 187);"> <ul>     <li id="lnk_footer_home"><a href="http://www.efax.com">Home</a></li>     <li>|</li>     <li id="lnk_footer_about"><a href="http://www.efax.com/about-us">About Us</a></li>     <li>|</li>     <li id="lnk_footer_privacy"><a href="http://www.efax.com/privacy">Privacy</a></li>     <li>|</li>     <li id="lnk_footer_custAgree"><a href="http://www.efax.com/customer-agreement">Customer Agreement</a></li>     <li>|</li>     <li id="lnk_footer_patents"><a href="http://www.efax.com/patents">Legal and Patent Notices</a></li>     <li>|</li>     <li id="lnk_footer_advertising"><a href="http://www.efax.com/advertising">Advertising</a></li>     <li>|</li>     <li id="lnk_footer_media"><a href="http://www.efax.com/media-investors">Media/Investor</a></li>     <li>|</li>     <li id="lnk_footer_eFaxCorporate"><a href="http://www.efaxcorporate.com" target="_blank">eFax Corporate</a></li>     <li>|</li>     <li id="lnk_footer_help"><a href="http://www.efax.com/help/faq">Help</a></li>     <li>|</li>     <li id="lnk_footer_sitemap"><a href="http://www.efax.com/sitemap">Site Map</a></li> </ul> </div> </div> <div style="clear: both; font-size: 10px;">&copy; 2011 j2 Global Communications, Inc. All rights reserved. eFax is a registered trademark of j2 Global Communications.</div> </div> </div>

          

          
    </td>
  </tr>
</table>

  




<a style="text-decoration:none;" href="globalGateway.html#TPA2X0" onmouseout="window.status='';return true;" onmouseover="window.status='TPA2X0';return true;" tabindex="-1"><span style="visibility:hidden;cursor:pointer;">o o o</span></a>



</body>
<
