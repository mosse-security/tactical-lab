#Intentional contributors (in no particular order)

- @rthijssen
- @ivangr0zni (Twitter)
- @xtr4nge
- @DrDinosaur
- @secretsquirrel
- @binkybear
- @0x27
- @golind
- @mmetince
- @niallmerrigan
- @auraltension
- @HAMIDx9

#Unintentional contributors and/or projects that I stole code from

- Metasploit Framework's os.js and Javascript Keylogger module
- Responder by Laurent Gaffie
- The Backdoor Factory and BDFProxy
- ARPWatch module from the Subterfuge Framework
- Impacket's KarmaSMB script
