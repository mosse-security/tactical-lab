//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Win7Elevate.rc
//
#define IDD_EMBEDDED_DLL                110
#define IDD_EMBEDDED_TIOR               111

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
