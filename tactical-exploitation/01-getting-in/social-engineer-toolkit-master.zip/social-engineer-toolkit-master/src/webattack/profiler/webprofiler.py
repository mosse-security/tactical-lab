#!/usr/bin/env python
#
# victim profile code here
#

from src.core.setcore import return_continue, print_info

def prep_website():
    print_info("This feature is currently under development and disabled.")
    return_continue()

prep_website()
