#PowerTools

Veil's PowerTools are a collection of PowerShell projects with a focus
on offensive operations.

Developed by [@harmj0y](https://twitter.com/harmj0y) and [@sixdub](https://twitter.com/sixdub)
