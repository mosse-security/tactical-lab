#PewPewPew

This repo contains scripts that utilize a common pattern to host a script
on a PowerShell webserver, invoke the IEX download cradle to 
download/execute the target code and post the results back to the server, 
and then post-process any results.

More details [here](http://www.harmj0y.net/blog/powershell/dumping-a-domains-worth-of-passwords-with-mimikatz-pt-2/)

Developed by [@harmj0y](https://twitter.com/harmj0y)

Part of Veil's [PowerTools](https://github.com/Veil-Framework/PowerTools)
