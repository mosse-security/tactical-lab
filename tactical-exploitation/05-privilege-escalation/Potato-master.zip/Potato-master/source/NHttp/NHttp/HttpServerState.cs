﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHttp
{
    public enum HttpServerState
    {
        Stopped,
        Starting,
        Started,
        Stopping
    }
}
