PAExec
======

Download
--------

Binary versions of PAExec are available at:

http://www.poweradmin.com/paexec/


What is it?
-----------

PAExec is a free, redistributable and open source equivalent
to Microsoft's popular PsExec application:

http://technet.microsoft.com/en-us/sysinternals/bb897553.aspx

Documentation
-------------

The main PAExec page shows all of the command line options.

http://www.poweradmin.com/paexec/

License
-------------
Basically anyone can use the software for private, public or commercial uses,
including using it as part of a distributed commercial application.
No payment or attribution is required.

The legalese that says the same thing:
http://www.poweradmin.com/paexec/paexec_eula.txt