#!/bin/bash
gcc -Wall -fPIC -shared -o proxify.o proxify.c -ldl
