#ifndef PROXIFY_H
#define PROXIFY_H

#define PROXY_CONNECT 1
#define RELAY_CONNECT 2
#define PROXY_WRITE 3
#define RELAY_WRITE 3
#define PROXY_READ 4
#define RELAY_READ 4
#define PROXY_CLOSE 5
#define REALY_CLOSE 5
#define PROXY_HOSTBYNAME 20
#endif

