#Pivoter - Defcon 23 Release

For a full tutorial visit: https://www.trustedsec.com/june-2015/new_walls_ladders/

More detailed documentation coming soon.

Pivoter written by Geoff Walton
