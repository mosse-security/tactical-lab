<?php
    print "<p id='links'><a href='./index.php'>Home</a> | <a href='./metcreator.php'>MetCreator</a> | <a href='./logout.php'>Logout</a></p>";
?>