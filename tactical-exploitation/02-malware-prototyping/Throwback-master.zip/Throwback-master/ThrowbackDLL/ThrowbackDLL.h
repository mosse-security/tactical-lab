#include "stdafx.h"

extern "C" __declspec( dllexport ) int WProcInit();