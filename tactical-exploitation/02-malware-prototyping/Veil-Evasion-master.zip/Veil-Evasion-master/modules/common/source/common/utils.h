#include "launch.h"
void xTBhKXCwjmtbPzH(void);
int TJsNyrJVzmEm(char *qyXPOfJnI, const char *MQOpiUrVCAWHuG);
int dzXGOfdQoJX(char *InQBmzDGbZXVLg, char *lToXYPOwHn);
void EassGiLlrepCN(void);
int VfKVdJSbVtNoD(LPWSTR MkchvTxTbeHdBCP);
void yGQmeqNRGjnQ(char *HKfOSKwjq, const char *BgaMbbVbxpqD);
void AyRMSmztL(char *obClYiBMeRlXvu, const char *wbjgLdIjexayesK);
int lkUjAnANcgqvAh(const ARCHIVE_STATUS *paPcfBRywsxF);
int UwfsEYT(LPWSTR hwgYJnFOLObi);
