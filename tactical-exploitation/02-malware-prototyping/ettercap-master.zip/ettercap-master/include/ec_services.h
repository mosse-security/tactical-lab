#ifndef ETTERCAP_SERVICES_H
#define ETTERCAP_SERVICES_H

EC_API_EXTERN int services_init(void);
EC_API_EXTERN char * service_search(u_int32 serv, u_int8 proto);


#endif

/* EOF */

// vim:ts=3:expandtab

