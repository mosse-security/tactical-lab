#ifndef EC_API_EXTERN
#error Move this header somewhere else
#endif

EC_API_EXTERN char * strcasestr(const char *hailstack, const char *needle);

/* EOF */
